<?php
header('location:views');;
